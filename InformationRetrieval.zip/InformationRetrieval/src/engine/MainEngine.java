package engine;

import view.SimpleSearchGUI;

public class MainEngine {

	public static void main(String[] args) {
		SimpleSearchGUI gui = new SimpleSearchGUI();
	}
}
